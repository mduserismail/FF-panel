package com.example.ffpanel
import android.content.Context

class Prefs(c: Context) {
    val sp = c.getSharedPreferences("panel", Context.MODE_PRIVATE)
    var x: Int get() = sp.getInt("x", 40); set(v) { sp.edit().putInt("x", v).apply() }
    var y: Int get() = sp.getInt("y", 200); set(v) { sp.edit().putInt("y", v).apply() }
    var size: Int get() = sp.getInt("size", 1); set(v) { sp.edit().putInt("size", v).apply() } // 0 compact,1 medium,2 expanded
    var bx: Int get() = sp.getInt("bx", 10); set(v) { sp.edit().putInt("bx", v).apply() }
    var by: Int get() = sp.getInt("by", 300); set(v) { sp.edit().putInt("by", v).apply() }
    fun reset() { sp.edit().clear().apply() }
}
