package com.example.ffpanel
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0A0A0F"))
            setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        fun t(s: String, sz: Float, c: Int) = TextView(this).apply { text = s; textSize = sz; setTextColor(c); setPadding(0, 0, 0, (12 * d).toInt()) }
        root.addView(t("FREE FIRE PANEL", 22f, Color.parseColor("#B026FF")))
        root.addView(t("A floating settings panel and crosshair practice tool. It does not read, modify or interact with any game.", 14f, Color.WHITE))
        root.addView(t("Permissions: 'Display over other apps' lets the panel float above other apps. Notifications show a Stop button while it runs.", 13f, Color.LTGRAY))
        status = t("", 14f, Color.parseColor("#22C55E")); root.addView(status)
        fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }.also { root.addView(it) }
        btn("1. Grant overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow notifications") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("Start floating panel") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Overlay permission denied. The floating panel can't run without it. Grant it above, or use the app without the overlay."
                status.setTextColor(Color.parseColor("#F87171"))
            } else startForegroundService(Intent(this, OverlayService::class.java))
        }
        btn("Open practice mode (no overlay needed)") { startActivity(Intent(this, PracticeActivity::class.java)) }
        btn("Stop floating panel") { startService(Intent(this, OverlayService::class.java).setAction("STOP")) }
        root.gravity = Gravity.TOP
        setContentView(root)
    }
    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val nt = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.text = "Overlay: ${if (ov) "granted" else "not granted"}  |  Notifications: ${if (nt) "granted" else "not granted"}"
        status.setTextColor(if (ov) Color.parseColor("#22C55E") else Color.parseColor("#FBBF24"))
    }
}
