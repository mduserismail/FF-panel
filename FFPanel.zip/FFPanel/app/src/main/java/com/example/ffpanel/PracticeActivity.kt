package com.example.ffpanel
import android.app.Activity
import android.os.Bundle

class PracticeActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(PracticeView(this, Prefs(this))) }
}
