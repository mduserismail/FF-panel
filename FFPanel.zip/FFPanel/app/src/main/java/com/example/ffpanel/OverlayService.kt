package com.example.ffpanel
import android.app.*
import android.content.*
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.format.DateFormat
import android.view.*
import android.widget.*
import java.util.Date

class OverlayService : Service() {
    private val PURPLE = Color.parseColor("#B026FF"); private val GREEN = Color.parseColor("#22C55E")
    private val BG = Color.parseColor("#0A0A0F"); private val ROW = Color.parseColor("#15101F")
    private lateinit var wm: WindowManager; private lateinit var prefs: Prefs; private lateinit var ctx: Context
    private var panel: View? = null; private var bubble: View? = null
    private var plp: WindowManager.LayoutParams? = null; private var blp: WindowManager.LayoutParams? = null
    private var body: LinearLayout? = null; private var scroll: ScrollView? = null
    private var tab = 0
    private val widths = intArrayOf(240, 290, 330); private val heights = intArrayOf(190, 250, 320)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dm() = resources.displayMetrics

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager; prefs = Prefs(this)
        val ch = "panel"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "Floating panel", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch).setContentTitle("Floating panel running")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        showPanel()
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") stopSelf(); return START_NOT_STICKY
    }
    override fun onDestroy() { panel?.let { safeRemove(it) }; bubble?.let { safeRemove(it) }; super.onDestroy() }
    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        plp?.let { clamp(it); applySize(); panel?.let { v -> safeUpdate(v, it) } }
        blp?.let { clamp(it, dp(48), dp(48)); bubble?.let { v -> safeUpdate(v, it) } }
    }
    private fun safeRemove(v: View) { try { wm.removeView(v) } catch (_: Exception) {} }
    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) { try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }
    private fun lp(w: Int) = WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        .apply { gravity = Gravity.TOP or Gravity.START }
    private fun clamp(l: WindowManager.LayoutParams, w: Int = l.width, h: Int = dp(120)) {
        l.x = l.x.coerceIn(0, (dm().widthPixels - w).coerceAtLeast(0)); l.y = l.y.coerceIn(0, (dm().heightPixels - h).coerceAtLeast(0))
    }
    private fun panelWidth() = minOf(dp(widths[prefs.size]), dm().widthPixels - dp(8))
    private fun applySize() {
        plp?.width = panelWidth()
        scroll?.layoutParams = LinearLayout.LayoutParams(-1, minOf(dp(heights[prefs.size]), (dm().heightPixels * 0.55).toInt()))
    }

    // ---------- helpers ----------
    private fun box(fill: Int, stroke: Int, r: Int, sw: Int = 1) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (sw > 0) setStroke(dp(sw), stroke) }
    private fun tv(t: String, sz: Float = 12f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun saved() = toast("Saved")
    private fun row(icon: String, label: String, tip: String, right: View) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = box(ROW, Color.parseColor("#3B1A5A"), 10); setPadding(dp(8), dp(6), dp(8), dp(6))
        addView(tv(icon, 14f, PURPLE)); addView(tv("  $label", 12f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        addView(right)
        setOnLongClickListener { toast(tip); true }   // long-press = tooltip
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) }
    }
    private fun toggle(key: String, def: Boolean) = Switch(ctx).apply {
        isChecked = prefs.sp.getBoolean(key, def)
        trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(GREEN, Color.DKGRAY))
        setOnCheckedChangeListener { _, v -> prefs.sp.edit().putBoolean(key, v).apply(); saved() }
    }
    private fun slider(key: String, def: Int, max: Int = 100) = SeekBar(ctx).apply {
        this.max = max; progress = prefs.sp.getInt(key, def); layoutParams = LinearLayout.LayoutParams(dp(90), -2)
        progressTintList = ColorStateList.valueOf(PURPLE); thumbTintList = ColorStateList.valueOf(PURPLE)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { prefs.sp.edit().putInt(key, p).apply(); if (key.startsWith("xh")) xh?.invalidate() } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { saved() }
        })
    }
    // Dropdown replacement: tap to cycle. (Spinner popups are unreliable in non-focusable overlay windows.)
    private fun selector(key: String, opts: List<String>) = TextView(ctx).apply {
        fun show() { text = "‹ ${opts[prefs.sp.getInt(key, 0).coerceIn(0, opts.size - 1)]} ›" }
        show(); setTextColor(PURPLE); textSize = 12f; background = box(BG, PURPLE, 8); setPadding(dp(8), dp(3), dp(8), dp(3))
        setOnClickListener { prefs.sp.edit().putInt(key, (prefs.sp.getInt(key, 0) + 1) % opts.size).apply(); show(); if (key.startsWith("xh")) xh?.invalidate(); saved() }
    }
    private fun button(t: String, c: Int = PURPLE, f: () -> Unit) = TextView(ctx).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; background = box(c, c, 8, 0)
        setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(4), dp(3), 0) } }
    private fun confirm(msg: String, yes: () -> Unit) {
        body?.removeAllViews()
        body?.addView(tv(msg, 13f, Color.WHITE, true))
        body?.addView(LinearLayout(ctx).apply {
            addView(button("Yes", Color.parseColor("#B91C1C")) { yes() }); addView(button("No", Color.DKGRAY) { renderTab() }) })
    }
    private var xh: CrosshairView? = null

    // ---------- panel ----------
    private fun showPanel() {
        bubble?.let { safeRemove(it) }; bubble = null
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; background = box(BG, PURPLE, 16, 2); setPadding(dp(8), dp(6), dp(8), dp(4)); elevation = dp(12).toFloat() }
        val l = lp(panelWidth()).apply { x = prefs.x; y = prefs.y }.also { plp = it }
        // header (drag handle)
        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL
            addView(LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(tv("FREE FIRE PANEL", 12f, Color.WHITE, true)); addView(tv("v1.0.0", 9f, Color.GRAY)) })
            fun ib(s: String, f: () -> Unit) = tv(s, 16f, PURPLE).apply { setPadding(dp(8), dp(2), dp(8), dp(2)); setOnClickListener { f() } }
            addView(ib("⚙") { tab = 3; renderTab() })
            addView(ib("⤢") { prefs.size = (prefs.size + 1) % 3; applySize(); safeUpdate(root, l); toast(listOf("Compact", "Medium", "Expanded")[prefs.size]) })
            addView(ib("—") { minimize() })
            addView(ib("✕") { confirm("Stop the floating panel?") { stopSelf() } })
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        head.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = l.x; oy = l.y }
                MotionEvent.ACTION_MOVE -> { l.x = ox + (e.rawX - sx).toInt(); l.y = oy + (e.rawY - sy).toInt(); clamp(l, l.width, root.height); safeUpdate(root, l) }
                MotionEvent.ACTION_UP -> { prefs.x = l.x; prefs.y = l.y }
            }; false  // false so header buttons still receive clicks
        }
        root.addView(head)
        // profile
        val pm = packageManager
        root.addView(LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(2))
            addView(tv("👤", 22f)); addView(LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0)
                addView(tv("Player", 12f, Color.WHITE, true)); addView(tv("Membership: Free", 10f, Color.GRAY))
                addView(tv("● Panel Active", 10f, GREEN)) }) })
        root.addView(tv("DEMON HEADX", 16f, PURPLE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4)) })
        val s = ScrollView(ctx).also { scroll = it }; val b = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }.also { body = it }
        s.addView(b); root.addView(s)
        // bottom nav
        root.addView(LinearLayout(ctx).apply { setPadding(0, dp(4), 0, 0)
            listOf("🏠" to "HOME", "🎯" to "AIM", "👁" to "VISUAL", "⚙" to "SETTINGS").forEachIndexed { i, (ic, nm) ->
                addView(tv("$ic\n$nm", 9f, PURPLE).apply { gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    setOnClickListener { tab = i; renderTab() } }) } })
        applySize(); renderTab()
        try { wm.addView(root, l); panel = root } catch (e: Exception) { toast("Couldn't show panel: ${e.message}"); stopSelf() }
    }
    private fun minimize() {
        panel?.let { safeRemove(it) }; panel = null
        val b = tv("FF", 14f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = box(BG, PURPLE, 24, 2) }
        val l = lp(dp(48)).apply { height = dp(48); x = prefs.bx; y = prefs.by }.also { blp = it }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = l.x; oy = l.y; moved = false }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - sx) > 10 || Math.abs(e.rawY - sy) > 10) moved = true
                    l.x = ox + (e.rawX - sx).toInt(); l.y = oy + (e.rawY - sy).toInt(); clamp(l, dp(48), dp(48)); safeUpdate(v, l) }
                MotionEvent.ACTION_UP -> { prefs.bx = l.x; prefs.by = l.y; if (!moved) showPanel() }
            }; true
        }
        try { wm.addView(b, l); bubble = b } catch (e: Exception) { toast("Couldn't show launcher: ${e.message}") }
    }

    // ---------- tabs ----------
    private fun renderTab() {
        val b = body ?: return; b.removeAllViews(); xh = null
        when (tab) {
            0 -> {
                val upd = DateFormat.format("yyyy-MM-dd", Date(packageManager.getPackageInfo(packageName, 0).lastUpdateTime)).toString()
                b.addView(row("●", "Panel status", "Whether the floating service is running.", tv("Running", 11f, GREEN)))
                b.addView(row("⬆", "Version / updated", "App version and last install/update date.", tv("1.0.0 · $upd", 10f, Color.GRAY)))
                b.addView(row("📶", "FPS / Ping", "No permitted data source is available, so nothing is shown.", tv("Unavailable", 11f, Color.GRAY)))
                b.addView(row("🔊", "Sound", "Quick toggle for panel sounds.", toggle("sound", true)))
            }
            1 -> {
                b.addView(row("🎯", "Aim sensitivity", "Setting for the practice screen only (coming in phase 2).", slider("aim_sens", 50)))
                b.addView(row("👆", "Touch sensitivity", "Setting for the practice screen only.", slider("touch_sens", 50)))
                b.addView(row("🎚", "Target preference", "Which target the practice mode spawns.", selector("target_pref", listOf("Head", "Chest", "Mixed"))))
            }
            2 -> {
                val c = CrosshairView(ctx, prefs).also { xh = it }
                b.addView(c, LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(5) })
                b.addView(row("🎨", "Color", "Crosshair color (preview inside this panel only).", selector("xh_color", listOf("Red", "Green", "Cyan", "Yellow", "White", "Purple"))))
                b.addView(row("◎", "Shape", "Crosshair shape.", selector("xh_shape", listOf("Plus", "Dot", "Circle"))))
                b.addView(row("↔", "Size", "Crosshair size.", slider("xh_size", 30)))
                b.addView(row("◐", "Opacity", "Crosshair opacity.", slider("xh_opacity", 100)))
            }
            else -> {
                b.addView(row("🌐", "Language", "Stored now; translated UI strings come in a later phase.", selector("lang", listOf("English", "Hindi", "Hinglish"))))
                b.addView(row("🔔", "Notifications", "Toggle panel notifications.", toggle("notif", true)))
                b.addView(row("✨", "Animations", "Toggle UI animations.", toggle("anim", true)))
                b.addView(LinearLayout(ctx).apply { addView(button("Reset defaults", Color.parseColor("#7F1D1D")) {
                    confirm("Reset all settings?") { prefs.reset(); toast("Settings reset"); tab = 0; renderTab() } }) })
            }
        }
    }
}
