package com.example.ffpanel
import android.content.Context
import android.graphics.*
import android.view.View

class CrosshairView(c: Context, private val p: Prefs) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f }
    companion object { val COLORS = intArrayOf(Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.WHITE, Color.parseColor("#B026FF")) }
    override fun onDraw(cv: Canvas) {
        val col = COLORS[p.sp.getInt("xh_color", 1).coerceIn(0, COLORS.size - 1)]
        paint.color = col; paint.alpha = (p.sp.getInt("xh_opacity", 100).coerceIn(10, 100) * 255 / 100)
        val r = (6 + p.sp.getInt("xh_size", 30) * 0.4f) * resources.displayMetrics.density / 2f
        val cx = width / 2f; val cy = height / 2f
        when (p.sp.getInt("xh_shape", 0)) {
            0 -> { cv.drawLine(cx - r, cy, cx + r, cy, paint); cv.drawLine(cx, cy - r, cx, cy + r, paint) }
            1 -> { paint.style = Paint.Style.FILL; cv.drawCircle(cx, cy, r / 3, paint); paint.style = Paint.Style.STROKE }
            else -> cv.drawCircle(cx, cy, r, paint)
        }
    }
}
