package com.example.ffpanel
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.random.Random

/** Standalone practice screen: drag to move the crosshair, tap FIRE to shoot moving targets. Entirely inside this app. */
class PracticeView(c: Context, private val p: Prefs) : View(c) {
    private class T(var x: Float, var y: Float, var vx: Float, var vy: Float, val r: Float)
    private val d = resources.displayMetrics.density
    private val targets = mutableListOf<T>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = 0f; private var cy = 0f; private var score = 0; private var shots = 0
    private var dragId = -1; private var lx = 0f; private var ly = 0f; private var last = 0L
    private fun fx() = width - 90 * d; private fun fy() = height - 90 * d; private fun fr() = 50 * d

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f
        if (targets.isEmpty()) repeat(3) { spawn() }
    }
    private fun spawn() {
        val big = p.sp.getInt("target_pref", 0).let { if (it == 0) 22 else if (it == 1) 34 else Random.nextInt(22, 35) } * d
        val s = (60 + Random.nextInt(80)) * d
        val a = Random.nextDouble(0.0, 6.28)
        targets.add(T(Random.nextFloat() * width, Random.nextFloat() * height * 0.7f, (Math.cos(a) * s).toFloat(), (Math.sin(a) * s).toFloat(), big))
    }
    private fun fire() {
        shots++
        val hit = targets.firstOrNull { hypot(cx - it.x, cy - it.y) <= it.r }
        if (hit != null) { score++; targets.remove(hit); spawn() }
    }
    override fun onDraw(cv: Canvas) {
        val now = System.nanoTime(); val dt = if (last == 0L) 0f else (now - last) / 1e9f; last = now
        cv.drawColor(Color.parseColor("#0A0A0F"))
        for (t in targets) {
            t.x += t.vx * dt; t.y += t.vy * dt
            if (t.x < t.r || t.x > width - t.r) t.vx = -t.vx
            if (t.y < t.r || t.y > height - t.r) t.vy = -t.vy
            t.x = t.x.coerceIn(t.r, width - t.r); t.y = t.y.coerceIn(t.r, height - t.r)
            paint.style = Paint.Style.FILL; paint.color = Color.parseColor("#6B21A8"); cv.drawCircle(t.x, t.y, t.r, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.parseColor("#B026FF"); cv.drawCircle(t.x, t.y, t.r, paint)
        }
        CrosshairView.draw(cv, p, paint, cx, cy, d)
        paint.style = Paint.Style.FILL; paint.color = Color.parseColor("#22C55E"); paint.alpha = 200
        cv.drawCircle(fx(), fy(), fr(), paint)
        paint.color = Color.WHITE; paint.alpha = 255; paint.textSize = 16 * d; paint.textAlign = Paint.Align.CENTER
        cv.drawText("FIRE", fx(), fy() + 6 * d, paint)
        paint.textAlign = Paint.Align.LEFT
        val acc = if (shots == 0) 0 else score * 100 / shots
        cv.drawText("Hits $score   Shots $shots   Accuracy $acc%", 16 * d, 32 * d, paint)
        paint.textSize = 11 * d; paint.color = Color.GRAY
        cv.drawText("Drag anywhere to aim. Back button exits.", 16 * d, 52 * d, paint)
        postInvalidateOnAnimation()
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val x = e.getX(i); val y = e.getY(i)
                if (hypot(x - fx(), y - fy()) < fr()) fire() else if (dragId == -1) { dragId = e.getPointerId(i); lx = x; ly = y }
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = e.findPointerIndex(dragId)
                if (idx >= 0) {
                    val k = (0.3f + p.sp.getInt("aim_sens", 50) / 50f) * (0.5f + p.sp.getInt("touch_sens", 50) / 100f)
                    cx = (cx + (e.getX(idx) - lx) * k).coerceIn(0f, width.toFloat()); cy = (cy + (e.getY(idx) - ly) * k).coerceIn(0f, height.toFloat())
                    lx = e.getX(idx); ly = e.getY(idx)
                }
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                if (e.getPointerId(i) == dragId || e.actionMasked == MotionEvent.ACTION_CANCEL) dragId = -1
        }
        return true
    }
}
