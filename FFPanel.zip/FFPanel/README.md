# FF Panel – phase 1 (core floating panel)
Status: SOURCE ONLY. Not compiled, not installed, not tested on any device.
Build: open this folder in Android Studio (Koala+), let Gradle sync, Run on a device or Build > Build APK.
Then: open app > grant overlay permission > allow notifications > Start floating panel.
Not yet implemented: config manager/import/export, login, search, help/privacy pages, practice mode, real translations.
